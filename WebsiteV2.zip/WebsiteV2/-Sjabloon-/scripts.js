function openPopupDecl() {
  document.getElementById("fotoPopupDecl").style.display = "flex";
}

function closePopupDecl() {
  document.getElementById("fotoPopupDecl").style.display = "none";
}

// Sluiten als je buiten de popup klikt
window.onclick = function(event) {
  const popup = document.getElementById("fotoPopupDecl");
  if (event.target === popup) {
    popup.style.display = "none";
  }
}




function openPopupSke() {
  document.getElementById("fotoPopupSke").style.display = "flex";
}

function closePopupSke() {
  document.getElementById("fotoPopupSke").style.display = "none";
}

// Sluiten als je buiten de popup klikt
window.onclick = function(event) {
  const popup = document.getElementById("fotoPopupSke");
  if (event.target === popup) {
    popup.style.display = "none";
  }
}


function openPopupLoop() {
  document.getElementById("fotoPopupLoop").style.display = "flex";
}

function closePopupLoop() {
  document.getElementById("fotoPopupLoop").style.display = "none";
}

// Sluiten als je buiten de popup klikt
window.onclick = function(event) {
  const popup = document.getElementById("fotoPopupLoop");
  if (event.target === popup) {
    popup.style.display = "none";
  }
}







function openPopupSet() {
  document.getElementById("fotoPopupSet").style.display = "flex";
}

function closePopupSet() {
  document.getElementById("fotoPopupSet").style.display = "none";
}

// Sluiten als je buiten de popup klikt
window.onclick = function(event) {
  const popup = document.getElementById("fotoPopupSet");
  if (event.target === popup) {
    popup.style.display = "none";
  }
}


function openPopupIniWifi() {
  document.getElementById("fotoPopupIniWifi").style.display = "flex";
}

function closePopupIniWifi() {
  document.getElementById("fotoPopupIniWifi").style.display = "none";
}

// Sluiten als je buiten de popup klikt
window.onclick = function(event) {
  const popup = document.getElementById("fotoPopupIniWifi");
  if (event.target === popup) {
    popup.style.display = "none";
  }
}


function openPopupIniInp() {
  document.getElementById("fotoPopupIniInp").style.display = "flex";
}

function closePopupIniInp() {
  document.getElementById("fotoPopupIniInp").style.display = "none";
}

// Sluiten als je buiten de popup klikt
window.onclick = function(event) {
  const popup = document.getElementById("fotoPopupIniInp");
  if (event.target === popup) {
    popup.style.display = "none";
  }
}


function openPopupmqttCon() {
  document.getElementById("fotoPopupmqttCon").style.display = "flex";
}

function closePopupmqttCon() {
  document.getElementById("fotoPopupmqttCon").style.display = "none";
}

// Sluiten als je buiten de popup klikt
window.onclick = function(event) {
  const popup = document.getElementById("fotoPopupmqttCon");
  if (event.target === popup) {
    popup.style.display = "none";
  }
}



function openPopupReadINP() {
  document.getElementById("fotoPopupReadINP").style.display = "flex";
}

function closePopupReadINP() {
  document.getElementById("fotoPopupReadINP").style.display = "none";
}

// Sluiten als je buiten de popup klikt
window.onclick = function(event) {
  const popup = document.getElementById("fotoPopupReadINP");
  if (event.target === popup) {
    popup.style.display = "none";
  }
}


function openPopupAF() {
  document.getElementById("fotoPopupAF").style.display = "flex";
}

function closePopupAF() {
  document.getElementById("fotoPopupAF").style.display = "none";
}

// Sluiten als je buiten de popup klikt
window.onclick = function(event) {
  const popup = document.getElementById("fotoPopupAF");
  if (event.target === popup) {
    popup.style.display = "none";
  }
}


function openPopupRPI() {
  document.getElementById("fotoPopupRPI").style.display = "flex";
}

function closePopupRPI() {
  document.getElementById("fotoPopupRPI").style.display = "none";
}

// Sluiten als je buiten de popup klikt
window.onclick = function(event) {
  const popup = document.getElementById("fotoPopupRPI");
  if (event.target === popup) {
    popup.style.display = "none";
  }
}


function openPopupNRL() {
  document.getElementById("fotoPopupNRL").style.display = "flex";
}

function closePopupNRL() {
  document.getElementById("fotoPopupNRL").style.display = "none";
}

// Sluiten als je buiten de popup klikt
window.onclick = function(event) {
  const popup = document.getElementById("fotoPopupNRL");
  if (event.target === popup) {
    popup.style.display = "none";
  }
}